<?php require_once(APPPATH.'/third_party/fpdf/fpdf.php');
class header_slip extends FPDF{
	public function Header(){
		$this->Image('assets/img/amilogo.jpg',3,1,2);
		$this->SetTextColor(0);
		$this->SetFont('Arial','B','12');
		$this->Cell(13,1,'PT. Anugrah Muda Indonesia',0,0,'C');
		$this->Ln($h=0.4);
		$this->SetFont('Arial','','9');
		$pdf->Cell(18.9,1,'Jl. Raya Kelapa Dua, Kav. Islamic Village Blok OI no. 5b Tangerang, Banten',0,0,'C');
		$pdf->Ln($h=0.4);
		$pdf->Cell(11.7,1,'Phone : 0821 1088 3095',0,0,'C');
		$this->Ln($h=0.4);
		$this->Line(3,3.1,18.3,3.1);
		$this->SetLineWidth(0.1);
		$this->Line(3,3.1,18.3,3.1);
		$this->SetLineWidth(0);
		$this->Ln();
		$this->Ln();
		$this->SetFont('Arial','B','14');
		$this->Cell(19,1,'Slip Gaji',0,0,'C');
		$this->Ln();		
			}
}
?>