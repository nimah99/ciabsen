<?php defined('BASEPATH') OR exit('No direct script access allowed');
class report_absensi extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->library('pdf');
        $this->load->library('indotgl');
    }
     function index(){
			$date1=$_POST['dari'];
			$date2=$_POST['sampai'];
		
$pdf=new FPDF('P','cm','A4');		
$pdf->Open();
$pdf->AliasNbPages();
$pdf->AddPage();
        $pdf->Image('assets/img/amilogo.jpg',2,1,2);
        $pdf->SetTextColor(0);
		$pdf->SetFont('Arial','B','12');
		$pdf->Cell(13,1,'PT. Anugrah Muda Indonesia',0,0,'C');
		$pdf->Ln($h=0.4);
		$pdf->SetFont('Arial','','9');
		$pdf->Cell(17.9,1,'Jl. Raya Kelapa Dua, Kav. Islamic Village Blok OI no. 5b Tangerang, Banten',0,0,'C');
		$pdf->Ln($h=0.4);
		$pdf->Cell(10.7,1,'Phone : 0821 1088 3095',0,0,'C');
		$pdf->Ln($h=0.4);
		$pdf->Line(2,3.1,19,3.1);
		$pdf->SetLineWidth(0.1);
		$pdf->Line(2,3.1,19,3.1);
		$pdf->SetLineWidth(0);
		$pdf->Ln();
		$pdf->Ln();
		$pdf->SetFont('Arial','B','14');
		$pdf->Cell(19,1,'Data Absensi',0,0,'C');
		$pdf->Ln($h=0.5);
		$pdf->SetFont('Arial','','12');
		$pdf->Cell(19,1,"Periode ".bulan($date1)." s/d ".bulan($date2)."",0,0,'C');
		$pdf->Ln($h=1.5);
		$pdf->SetFont('Arial','B','9');
		$pdf->SetFillColor(255,0,0);
		$pdf->SetLineWidth(0.01);
		$pdf->SetDrawColor(255,0,0);
		$pdf->SetTextColor(255);
		$pdf->Cell(1);
		$pdf->Cell(1,0.5,'No','LTB',0,'C',1);
		$pdf->Cell(2,0.5,'NIK','LTB',0,'C',1);		
		$pdf->Cell(5,0.5,'Nama','LTB',0,'C',1);
		$pdf->Cell(3,0.5,'Masuk','LTB',0,'C',1);
		$pdf->Cell(3,0.5,'Pulang','LTB',0,'C',1);
		$pdf->Cell(1.5,0.5,'Absensi','LTB',0,'C',1);
		$pdf->Cell(1.5,0.5,'Lembur','LRTB',0,'C',1);
        $pdf->Ln();	
$pdf->SetFont('Arial','','8');
$pdf->SetTextColor(0);
$pdf->SetLineWidth(0.01);
$pdf->SetDrawColor(255,0,0);
$j=1;
$data=$this->db->query("SELECT profil.nik,profil.name,absensi.masuk,absensi.pulang,count(absensi.nik) as absen,sum(absensi.lembur) as overtime FROM profil left join absensi on absensi.nik=profil.nik WHERE tanggal BETWEEN '$date1' AND '$date2' group by absensi.nik")->result();
foreach ($data as $row){
	$pdf->Cell(1);
	$pdf->Cell(1,0.5,$j++,'LB',0,'C');
	$pdf->Cell(2,0.5,$row->nik,'LB',0,'C');
	$pdf->Cell(5,0.5,$row->name,'LB',0,'L');
	$pdf->Cell(3,0.5,$row->masuk,'LB',0,'C');
	$pdf->Cell(3,0.5,$row->pulang,'LB',0,'C');
	$pdf->Cell(1.5,0.5,format_angka($row->absen),'LB',0,'C');
	$pdf->Cell(1.5,0.5,format_angka($row->overtime),'LRB',0,'C');
$pdf->Ln();
}
$pdf->Output($name='data-absensi.pdf',$dest='I');
    } 
   
}
?>