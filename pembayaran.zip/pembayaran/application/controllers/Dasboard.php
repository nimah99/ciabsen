<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Dasboard extends CI_Controller{
     function __construct(){
		parent::__construct();
        $this->load->helper('url');
    }
    public function index(){
        $this->load->view('home');
        $this->load->view('dasboard');
  /*       $this->load->model('dasboard_model');
        $records=$this->dasboard_model->getRecords();
        $this->load->view('dasboard',['records'=>$records]);  */
    }
}
?>