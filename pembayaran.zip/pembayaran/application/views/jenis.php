<?php $this->load->view('header'); ?> 
<?php $this->load->view('side'); ?> 

    
<div id="content-wrapper">
    
<div class="container-fluid">
     <!-- Breadcrumbs-->
     <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Jenis Pembayaran</li>
        </ol>

        <div class="row">
        <div class="container">
      <div class="card-header"><i class="fas fa-edit"></i> Form Jenis Pembayaran</div>
      <div class="card-body">
      <form>
        <div class="col-md-6">
            <div class="form-group">
                <div class="form-row">
                  <div class="col-md-6">
                    <div class="form-label-group">
                      <input type="text" id="jp" class="form-control" placeholder="Jenis Pembayaran" required="required">
                      <label for="jp">Jenis Pembayaran</label>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-label-group">
                      <input type="text" id="tingkat" class="form-control" placeholder="Tingkat" required="required">
                      <label for="tingkat">Tingkat</label>
                    </div>
                  </div>
                </div>
           </div> 
        <a class="btn btn-primary btn-block" href="index.html">Simpan</a>
        </div>
        </form>
      </div>
    </div>
        </div>
        <!-- DataTables Example -->
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Data Pembayaran</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>NIS</th>
                    <th>Nama Siswa</th>
                    <th>Tingkat</th>
                    <th>Tahun Pelajaran</th>
                    <th>Nama Wali</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                  <th>NIS</th>
                    <th>Nama Siswa</th>
                    <th>Tingkat</th>
                    <th>Tahun Pelajaran</th>
                    <th>Nama Wali</th>
                    <th>Aksi</th>
                  </tr>
                </tfoot>
                <tbody>
                  <tr>
                    <td>Brielle Williamson</td>
                    <td>Integration Specialist</td>
                    <td>New York</td>
                    <td>61</td>
                    <td>2012/12/02</td>
                    <td>$372,000</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        <!--   <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div> -->
        </div>



        <?php $this->load->view('footer'); ?>