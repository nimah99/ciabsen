<?php $this->load->view('topmenu'); ?> 
<?php $this->load->view('sidemenu'); ?> 
<section id="main-content">
<section class="wrapper">
    <h3><i class="fa fa-angle-right"></i> Rekap Gaji</h3>

    <!-- BASIC FORM ELELEMNTS -->
    <div class="row mt">
          		<div class="col-lg-12">
                  <div class="form-panel">
                  <div class="form-group">
                              <div class="col-sm-8">
                                <input type="checkbox" name="thrcb" id="thrcb">
                                <label>Tambahkan THR</label>
                              </div>
                          </div>
                  <?php echo form_open('rekap_gaji/insert',['class'=>'form-horizontal']);?>
					   <div class="col-sm-6">
                       <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">NIK</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="nik" id="nik" placeholder="Ketik NIK di sini" autocomplete="off" autofocus required>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Nama</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="nama" id="nama" disabled>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Jabatan</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="jabatan" id="jabatan" disabled>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Department</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="dept" id="dept" disabled>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Gaji Pokok</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="gapok" id="gapok" disabled>
                              </div>
                          </div>

 	
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Harian</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="harian" id="harian" disabled>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Uang Makan</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="makan" id="makan" disabled>
                              </div>
                          </div>
                          </div>
                        <div class="col-sm-6">
                        <input type="hidden" name="thr" id="thr">
                        <input type="hidden" name="ststhr" id="ststhr">
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Uang Transport</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="transport" id="transport" disabled>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Tunj. Kesehatan</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="tkesehatan" id="tkesehatan" disabled>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Lembur (per jam)</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="lembur" id="lembur" disabled>
                              </div>
                          </div>
                          
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Total Absensi</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="tabsensi" id="tabsensi" required>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Total Lembur</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="tlembur" id="tlembur" required>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Total Gaji</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="tgaji" id="tgaji" required>
                              </div>
                          </div>

 </div>			 
 
<input type="button" class="btn btn-default" onclick="total();" value="Hitung"/>
<?php echo form_submit(['value'=>'Rekap','class'=>'btn btn-theme']);?>
<?php echo form_close();?>
                           <?php 
$data=$this->session->flashdata('sukses');
if($data!=""){ ?>
<div class="alert alert-dismissible alert-success" role="alert"><strong><?=$data;?> </strong>
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php } ?>
<?php 
$data2=$this->session->flashdata('error');
if($data2!=""){ ?>
<div class="alert alert-dismissible alert-danger"><strong> <?=$data2;?> </strong>
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php } ?>					              
                  </div>
          		</div><!-- col-lg-12-->
          	</div><!-- /row -->
</section>
</section>
<?php $this->load->view('footer'); ?>  
<script type="text/javascript" charset="utf-8">
			$(document).ready(function(){
                var config = {
                    source: '<?php echo ('rekap_gaji/carikaryawan')?>',			
					select: function(event, ui){
                        $("#tlembur").val(ui.item.tlembur);
                        $("#tabsensi").val(ui.item.tabsensi);
						$("#lembur").val(ui.item.lembur);
						$("#tkesehatan").val(ui.item.tkesehatan);
                        $("#thr").val(ui.item.thr);
                        $("#transport").val(ui.item.transport);
						$("#makan").val(ui.item.makan);
                        $("#harian").val(ui.item.harian);
						$("#gapok").val(ui.item.gapok);
						$("#dept").val(ui.item.department);
						$("#jabatan").val(ui.item.jabatan);
						$("#nama").val(ui.item.name);
						$("#nik").val(ui.item.nik);
					},
					minLength: 1
				};
				$("#nik").autocomplete(config);
			});	
            function total(){
                var checkBox = document.getElementById("thrcb");	
                thr = parseInt(document.getElementById('thr').value);
                gapok = parseInt(document.getElementById('gapok').value);		
				makan = parseInt(document.getElementById('makan').value) * parseInt(document.getElementById('tabsensi').value);		
				transport = parseInt(document.getElementById('transport').value) * parseInt(document.getElementById('tabsensi').value);	
				kesehatan = parseInt(document.getElementById('tkesehatan').value);
				absensi = parseInt(document.getElementById('harian').value) * parseInt(document.getElementById('tabsensi').value);			
				lembur = parseInt(document.getElementById('tlembur').value) * parseInt(document.getElementById('lembur').value);	     
                    if (checkBox.checked == true){
                        document.getElementById('tgaji').value = gapok + absensi + makan + transport + kesehatan + thr + lembur;
                        document.getElementById('ststhr').value= 1;
                    } else {
                        document.getElementById('tgaji').value = gapok + absensi + makan + transport + kesehatan + lembur;
                        document.getElementById('ststhr').value= 0;
                    }
                 }
            </script>