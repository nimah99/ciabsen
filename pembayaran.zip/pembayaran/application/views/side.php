<div id="wrapper">
  <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item <?php if($this->uri->uri_string() == 'dasboard') { echo 'active'; } ?>">
        <a class="nav-link" href="<?php echo site_url('dasboard'); ?>">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item <?php if($this->uri->uri_string() == 'siswa') { echo 'active'; } ?>">
        <a class="nav-link" href="<?php echo site_url('siswa'); ?>">
          <i class="fas fa-fw fa-school"></i>
          <span>Master Siswa</span></a>
      </li>
      <li class="nav-item <?php if($this->uri->uri_string() == 'pembayaran') { echo 'active'; } ?>">
        <a class="nav-link" href="<?php echo site_url('pembayaran'); ?>">
          <i class="fas fa-fw fa-clipboard-list"></i>
          <span>Pembayaran</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-cogs"></i>
          <span>Settings</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item <?php if($this->uri->uri_string() == 'jenis') { echo 'active'; } ?>" href="<?php echo site_url('jenis'); ?>">Jenis Pembayaran</a>
          <a class="dropdown-item <?php if($this->uri->uri_string() == 'ta') { echo 'active'; } ?>" href="<?php echo site_url('ta'); ?>">Tahun Ajaran</a>
        </div>
      </li>
    </ul>
