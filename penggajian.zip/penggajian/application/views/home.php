<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <!--  <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina"> -->

	<link rel="shourt icon" href=<?php echo base_url("assets/img/amilogo.jpg")?>>	
    <title>PT. Anugrah Muda Indonesia</title>

  
    <link href=<?php echo base_url("assets/css/bootstrap.css")?> rel="stylesheet">
    <link href=<?php echo base_url("assets/css/jquery-ui-1.9.2.custom.css")?> rel="stylesheet">
    <link href=<?php echo base_url("assets/css/style.css")?> rel="stylesheet">
    <link href=<?php echo base_url("assets/css/color.css")?> rel="stylesheet">
    <link href=<?php echo base_url("assets/font-awesome/css/font-awesome.css")?> rel="stylesheet" />
    <link href=<?php echo base_url("assets/css/style-responsive.css")?> rel="stylesheet">

    <link href=<?php echo base_url("assets/css/table-responsive.css")?> rel="stylesheet">
    <link href=<?php echo base_url("assets/js/dataTables/dataTables.bootstrap.css")?> rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href=<?php echo base_url("assets/css/zabuto_calendar.css")?>>
  </head>
  <body>
  <section id="container" >
      
 