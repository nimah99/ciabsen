-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 23 Jun 2019 pada 05.49
-- Versi Server: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud_ci`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `absensi`
--

CREATE TABLE `absensi` (
  `idabsen` varchar(25) NOT NULL,
  `tanggal` date NOT NULL,
  `nik` varchar(99) NOT NULL,
  `masuk` datetime NOT NULL,
  `pulang` datetime NOT NULL,
  `lembur` int(1) NOT NULL,
  `keterangan` varchar(99) NOT NULL,
  `status` int(11) NOT NULL,
  `rekap` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `absensi`
--

INSERT INTO `absensi` (`idabsen`, `tanggal`, `nik`, `masuk`, `pulang`, `lembur`, `keterangan`, `status`, `rekap`) VALUES
('2019040112345', '2019-04-01', '12345', '2019-04-01 08:26:36', '2019-04-01 17:18:37', 0, 'Tepat', 1, 1),
('20190401123456', '2019-04-01', '123456', '2019-04-01 08:27:44', '2019-04-01 17:18:38', 0, 'Tepat', 1, 1),
('2019040112479', '2019-04-01', '12479', '2019-04-01 08:27:51', '2019-04-01 17:24:41', 0, 'Tepat', 1, 1),
('2019040113456', '2019-04-01', '13456', '2019-04-01 09:35:20', '2019-04-01 17:26:42', 0, 'Terlambat', 1, 1),
('2019040113536', '2019-04-01', '13536', '2019-04-01 08:27:59', '2019-04-01 17:25:43', 0, 'Tepat', 1, 1),
('2019040123456', '2019-04-01', '23456', '2019-04-01 08:23:01', '2019-04-01 17:25:44', 0, 'Tepat', 1, 1),
('2019040124567', '2019-04-01', '24567', '2019-04-01 08:29:28', '2019-04-01 17:27:46', 0, 'Tepat', 1, 1),
('2019062313456', '2019-06-23', '13456', '2019-06-23 09:29:18', '0000-00-00 00:00:00', 0, 'Terlambat', 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `dept`
--

CREATE TABLE `dept` (
  `iddept` int(11) NOT NULL,
  `department` varchar(99) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `dept`
--

INSERT INTO `dept` (`iddept`, `department`) VALUES
(5, 'Informasi Teknologi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatan`
--

CREATE TABLE `jabatan` (
  `idlvl` int(11) NOT NULL,
  `jabatan` varchar(99) NOT NULL,
  `gapok` varchar(12) NOT NULL,
  `harian` varchar(12) NOT NULL,
  `makan` varchar(12) NOT NULL,
  `transport` varchar(12) NOT NULL,
  `kesehatan` varchar(12) NOT NULL,
  `thr` varchar(12) NOT NULL,
  `lembur` varchar(12) NOT NULL,
  `iddept` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jabatan`
--

INSERT INTO `jabatan` (`idlvl`, `jabatan`, `gapok`, `harian`, `makan`, `transport`, `kesehatan`, `thr`, `lembur`, `iddept`) VALUES
(4, 'Staff', '2500000', '50000', '35000', '20000', '300000', '400000', '25000', 5),
(5, 'CEO', '15000000', '150000', '1500000', '500000', '300000', '15000000', '50000', 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jam_kerja`
--

CREATE TABLE `jam_kerja` (
  `idkerja` int(11) NOT NULL,
  `mulai_masuk` time NOT NULL,
  `boleh_pulang` time NOT NULL,
  `lambat_masuk` int(11) NOT NULL,
  `lambat_pulang` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jam_kerja`
--

INSERT INTO `jam_kerja` (`idkerja`, `mulai_masuk`, `boleh_pulang`, `lambat_masuk`, `lambat_pulang`) VALUES
(2, '08:00:00', '17:00:00', 35, 30);

-- --------------------------------------------------------

--
-- Struktur dari tabel `payroll`
--

CREATE TABLE `payroll` (
  `idpayroll` varchar(99) NOT NULL,
  `nik` varchar(99) NOT NULL,
  `total_absensi` int(11) NOT NULL,
  `total_lembur` int(11) NOT NULL,
  `total_gaji` varchar(15) NOT NULL,
  `tgl` date NOT NULL,
  `thr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `payroll`
--

INSERT INTO `payroll` (`idpayroll`, `nik`, `total_absensi`, `total_lembur`, `total_gaji`, `tgl`, `thr`) VALUES
('20190412345', '12345', 1, 0, '3305000', '2019-04-23', 1),
('201904123456', '123456', 1, 0, '2905000', '2019-04-23', 0),
('201906123456', '123456', 1, 0, '3305000', '2019-06-23', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `profil`
--

CREATE TABLE `profil` (
  `nik` varchar(99) NOT NULL,
  `name` varchar(225) NOT NULL,
  `gender` int(11) NOT NULL,
  `religion` int(11) NOT NULL,
  `tmpt_lahir` varchar(99) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `telp` varchar(15) NOT NULL,
  `alamat` text NOT NULL,
  `idlvl` int(11) NOT NULL,
  `foto` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `profil`
--

INSERT INTO `profil` (`nik`, `name`, `gender`, `religion`, `tmpt_lahir`, `tgl_lahir`, `telp`, `alamat`, `idlvl`, `foto`) VALUES
('12345', 'utsman', 2, 3, 'jakarta', '1994-07-07', '08989879989', 'jakarta', 4, './gambar/e04f0f2cb6f2c12085fc958c23f720b6.jpeg'),
('123456', 'afrizal', 2, 3, 'jakarta', '1994-08-08', '08989889989', 'jakarta', 4, './gambar/15b69d6cd571ca20c8030fd5b98b825b.jpeg'),
('12479', 'video upload', 1, 3, 'jakarta', '2019-02-07', '3494955894', 'jakarta', 4, './gambar/38441f644e27432d27b058f9385cfedb.jpg'),
('13456', 'arshad', 2, 3, 'jakarta', '1994-08-08', '08989889989', 'jakarta', 4, './gambar/d6e2815efea0cefcda9bcb8831280c52.jpeg'),
('13536', 'aslan', 2, 3, 'jakarta', '1997-06-19', '08989879989', 'jakarta', 4, './gambar/bf8c09731ab0a94bda2cb1a6afd1bf05.jpeg'),
('23456', 'shandy', 2, 3, 'jakarta', '1993-09-09', '08989879989', 'jakarta', 4, './gambar/e054501afc07747df3f0d9e540492f1a.jpeg'),
('24567', 'ulfah', 1, 3, 'jakarta', '1994-08-09', '08989889989', 'jakarta', 4, './gambar/c4cacfc9f0123b2f327e06bac6e4c258.jpeg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `u`
--

CREATE TABLE `u` (
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `level` int(11) NOT NULL,
  `created` date NOT NULL,
  `nik` varchar(99) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `u`
--

INSERT INTO `u` (`email`, `password`, `level`, `created`, `nik`, `status`) VALUES
('efi', '$2y$12$56KxUijptObYvXTnj2OPn.zbCCBmgB6eMlmmiEn5whP/4b9NDM6Ju', 1, '2019-06-23', '', 1),
('nimah', '$2y$12$FvVRIMvSzyBkyV7AHTEMO.fhuYXlNhxQ6oIJKr.cH9WhyfXZsE/3i', 1, '0000-00-00', '', 0),
('users', '$2y$12$Ai5CCOFuu33NT8.4se1NWewiYlb69JM4mYNtiq0XOo0nREYC8MJ4m', 2, '2018-12-07', '', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`idabsen`);

--
-- Indexes for table `dept`
--
ALTER TABLE `dept`
  ADD PRIMARY KEY (`iddept`);

--
-- Indexes for table `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`idlvl`);

--
-- Indexes for table `jam_kerja`
--
ALTER TABLE `jam_kerja`
  ADD PRIMARY KEY (`idkerja`);

--
-- Indexes for table `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`idpayroll`);

--
-- Indexes for table `profil`
--
ALTER TABLE `profil`
  ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `u`
--
ALTER TABLE `u`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dept`
--
ALTER TABLE `dept`
  MODIFY `iddept` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jabatan`
--
ALTER TABLE `jabatan`
  MODIFY `idlvl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jam_kerja`
--
ALTER TABLE `jam_kerja`
  MODIFY `idkerja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
